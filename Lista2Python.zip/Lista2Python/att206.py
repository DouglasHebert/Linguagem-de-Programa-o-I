input_lista1 = input("Digite os elementos da primeira lista separados por espaços: ")

lista1 = input_lista1.split()

input_lista2 = input("Digite os elementos da segunda lista separados por espaços: ")

lista2 = input_lista2.split()

lista3 = lista1 + lista2

print("A terceira lista combinada é:", lista3)
